////a class that "figures out" what the user entered and prepares three things: an operand stack, an operator stack,
////and a queue which holds the expression that needs to be translated from algebraic to RPN.
////(NOTE: This implies that the queue must hold different data types -- operands, parens, and operators)


//#include "parser.h"
//#include <iostream>

//parser<T>::parser()
//{
//    getInput();
//}

//parser<T>::~parser()
//{

//}

//void parser::getInput()
//{
//    char temp=' ';

//    while(temp!=10)//10 is ascii for new line aka enter button
//    {
//        temp=cin.get();

//        if (temp!=10)
//        {
//            userInput.enqueue(temp);
//        }

//        std::cout<<userInput;

//    }
//}

